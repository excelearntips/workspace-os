import { PrismaClient } from "@prisma/client";

// Mencegah terlalu banyak koneksi database saat hot-reload di development
// dan saat cold start berulang di Vercel serverless functions.
const globalForPrisma = global as unknown as { prisma: PrismaClient };

export const prisma =
  globalForPrisma.prisma ||
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["query", "error", "warn"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
