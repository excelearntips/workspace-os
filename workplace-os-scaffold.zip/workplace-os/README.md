# Workplace OS

New Manager Workplace Hub — Next.js (App Router, TypeScript) + Prisma + Tailwind, di-deploy ke Vercel.

## 1. Push ke GitHub

```bash
cd workplace-os
git init
git add .
git commit -m "Initial scaffold: Workplace OS"
```

Buat repo baru di https://github.com/new (jangan centang "Initialize with README"), lalu:

```bash
git remote add origin https://github.com/<username>/workplace-os.git
git branch -M main
git push -u origin main
```

## 2. Setup database (pilih satu)

**Neon** (https://neon.tech) — buat project baru, region terdekat (misal Singapore).
Dari dashboard, salin:
- **Pooled connection string** → `DATABASE_URL`
- **Direct connection string** → `DIRECT_URL`

**Supabase** (https://supabase.com) — buat project baru, ambil connection string dari
Project Settings → Database. Gunakan connection pooling (port 6543) untuk `DATABASE_URL`
dan direct connection (port 5432) untuk `DIRECT_URL`.

## 3. Deploy ke Vercel

1. Buka https://vercel.com/new, import repo GitHub yang barusan dibuat.
2. Framework preset otomatis terdeteksi sebagai **Next.js** — tidak perlu diubah.
3. Di bagian **Environment Variables**, tambahkan `DATABASE_URL` dan `DIRECT_URL`
   dari langkah 2.
4. Klik **Deploy**.

Vercel akan otomatis build ulang setiap kali ada push ke `main` (production) atau
membuat preview deployment untuk setiap pull request.

## 4. Migrasi database setelah deploy pertama

Jalankan dari lokal (dengan `.env` sudah berisi `DATABASE_URL` dan `DIRECT_URL`):

```bash
npm install
npx prisma migrate dev --name init
```

Ini akan membuat semua tabel (User, Task, JournalEntry, Delegation, OneOnOne,
WorkloadEntry, Stakeholder, StatusUpdate, RiskLog, dll) di database production.

## 5. Development lokal

```bash
cp .env.example .env   # isi dengan DATABASE_URL & DIRECT_URL kamu
npm install
npm run dev
```

Buka http://localhost:3000

## Struktur project

```
app/            → routes (App Router)
prisma/schema.prisma → skema database (3 pillar: Self, Team, Stakeholder)
lib/prisma.ts   → Prisma client singleton (aman untuk serverless)
lib/utils.ts    → helper className (cn)
```
