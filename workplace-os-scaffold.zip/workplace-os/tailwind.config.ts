import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        sage: {
          50: "#f4f7f2",
          100: "#e6ede1",
          200: "#cddbc4",
          300: "#aac29b",
          400: "#87a674",
          500: "#6b8c58",
          600: "#547044",
          700: "#425838",
          800: "#37472f",
          900: "#2f3c29",
        },
      },
      borderRadius: {
        card: "1.25rem",
      },
      fontFamily: {
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};

export default config;
