import { Target, Users, Handshake, ArrowRight } from "lucide-react";
import Link from "next/link";

const pillars = [
  {
    href: "/self",
    icon: Target,
    title: "Manage Self",
    description: "Priority matrix, fokus harian, dan pengelompokan tugas.",
  },
  {
    href: "/team",
    icon: Users,
    title: "Manage Team",
    description: "Delegasi, 1-on-1, dan kapasitas beban kerja tim.",
  },
  {
    href: "/stakeholder",
    icon: Handshake,
    title: "Manage Stakeholder",
    description: "Pemetaan stakeholder, status update, dan log risiko.",
  },
];

export default function Home() {
  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col gap-6 px-5 py-10 sm:max-w-2xl">
      <header className="space-y-1">
        <p className="text-sm font-medium text-sage-500">Selamat datang kembali</p>
        <h1 className="text-2xl font-semibold text-sage-900">Workplace OS</h1>
      </header>

      <section className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        {pillars.map(({ href, icon: Icon, title, description }) => (
          <Link
            key={href}
            href={href}
            className="group flex flex-col justify-between gap-4 rounded-card border border-sage-100 bg-white p-5 shadow-sm transition hover:border-sage-300 hover:shadow-md"
          >
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-sage-100 text-sage-600">
              <Icon size={20} strokeWidth={2} />
            </div>
            <div className="space-y-1">
              <h2 className="font-semibold text-sage-900">{title}</h2>
              <p className="text-sm leading-relaxed text-sage-700">{description}</p>
            </div>
            <span className="flex items-center gap-1 text-sm font-medium text-sage-600 group-hover:gap-2">
              Buka
              <ArrowRight size={16} className="transition-all" />
            </span>
          </Link>
        ))}
      </section>
    </main>
  );
}
